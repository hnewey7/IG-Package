'''
Package for easily using IG Group's API.

Created on Tuesday 12th March 2024.
@author: Harry New

'''

from .main import IG, Watchlist, Instrument